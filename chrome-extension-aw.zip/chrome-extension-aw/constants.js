const APP_NAME = "AW Civilizer"

const LOCAL_STORAGE_KEY_NAME = '_ku_data'

const ACRONYM_TO_SERVICE_REGEX = {
    'OWO': [/Oral without Protection\n/, "😋"],
    'CIM': [/CIM/, "👄"],
    'Swallow': [/Swallow/, "💊"],
    'Anal': [/"A"Levels\n/, "🍩"],
    'DFK': [/French Kissing\n/, "😘"],
    'Foot Worship': [/Foot Worship/, "👣"],
    'Rimming': [/Rimming \(giving\)/, "👅"],
    'Massage': [/Massage/, "💆‍♂️"],
    'HR': [/Hand Relief/, "✊"],
    'Strap On': [/Strap On/, "👺"],
    'WS': [/Watersports/, "🏄"],
    'BB': [/(Bareback|Unprotected Sex)/, "🤮"],
    'DT': [/Deep Throat/, "🧕"],
    'Tie & Tease': [/Tie & Tease/, "✝️"],
};